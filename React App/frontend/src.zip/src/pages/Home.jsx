import { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { toast } from 'react-toastify'
import Navbar from '../components/Navbar'
import config from '../config'
import { addItem } from '../features/cartSlice'
import { getAllPizzas } from '../services/pizza'

function Pizza({ item }) {
  // get the dispatch object
  const dispatch = useDispatch()

  const getTitle = () => {
    return item.name.length > 13
      ? item.name.substring(0, 12) + '...'
      : item.name
  }

  return (
    <div className='card' style={{ height: 280 }}>
      <div style={{ textAlign: 'center' }}>
        <img
          style={{ width: 150 }}
          className='card-img-top'
          src={config.server + '/' + item.image}
          alt=''
        />
      </div>
      <div className='card-body'>
        <div style={{ fontWeight: 'bold', fontSize: 19 }}>{getTitle()}</div>
        <div>
          Price:{' '}
          <span style={{ fontWeight: 'bold', fontSize: 17 }}>
            ₹{item.price}
          </span>
        </div>
        <div className='mt-2'>
          <button  className='btn btn-success btn-sm'>
            Add
          </button>
        </div>
      </div>
    </div>
  )
}

export function Home() {
  const [items, setItems] = useState([])
  const loadAllPizzas = async () => {
    const result = await getAllPizzas()
    if (result['message'] == 'success') {
      //console.log(result['result'])
      setItems(result['result'])
      items.map(item=>{
        console.log(item)
      })
    } else {
      toast.error(result['error'])
    }
  }

  useEffect(() => {
    loadAllPizzas()
  }, [])

  console.log("items", items)

  return (
    <>
      <Navbar />
      <h1>Helli</h1>
      <div>
        {items.map((item, index) => {
          //console.log("item from map",typeof item)
          return (
            <div>
                <h1 key={index}>{item.CarID}</h1>
            </div>
          
          )
        })} 
        
        </div>     
      {/* {
                                users.map(user=>{
                                 if(searchText!=="")
                                 {
                                    if(user.Address.toLowerCase().includes(searchText.toLowerCase()))
                                    {
                                      return <tr key={user.No}>
                                            <td>{user.No}</td>
                                            <td>{user.Name}</td>
                                            <td>{user.Address}</td> 
                                            <td>
                                            <button className='btn btn-danger' 
                                            onClick={
                                                ()=>
                                                {
                                                RemoveRecord(user.No)
                                                }
                                            }>
                                                Delete
                                            </button>
                                            </td>
                                            <td>
                                            <button className='btn btn-warning' 
                                            onClick={
                                                ()=>
                                                {
                                                EditRecord(user.No)
                                                }
                                            }>
                                               Edit
                                            </button>
                                            </td>
                                             </tr>
                                    } */}
    </>
  )
}

export default Home
